package com.lijunjie.tmall.service;

import com.lijunjie.tmall.bean.Review;

public interface ReviewService {
	public Integer addReview(Review review);
}
